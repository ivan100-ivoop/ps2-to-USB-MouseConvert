﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Runtime.InteropServices;
using System.Threading;
using System.IO.Ports;

namespace Mouse
{
    public partial class Form1 : Form
    {
        SerialPort myport;
        MouseControll controller;
        Thread response;
        String mydata;
        public int delay = 10;
        public Form1()
        {
            InitializeComponent();
            richTextBox1.Enabled = false;
            timer2.Start();
            controller = new MouseControll(this);
        }

        private void Ports()
        {
            if (comboBox1.Items.Count > 0)
            {
                comboBox1.Items.Clear();
            }
            String[] ports = SerialPort.GetPortNames();
            for (int i = 0; i < ports.Length; i++)
            {
                comboBox1.Items.Add(ports[i]);
            }
            if (ports.Length > 0)
            {
                comboBox1.SelectedIndex = 0;
            }
            else
            {
                comboBox1.Text = "";
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string port = comboBox1.Text;
            if (myport == null || !myport.IsOpen)
            {
                ConnectToUSB(port, 9600);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (myport.IsOpen)
            {
                timer1.Stop();
                timer2.Stop();
                if (response != null && response.IsAlive)
                {
                    response.Abort();
                    response = null;
                }
                myport.Close();
                resetPoint();
            }
        }

        private void ConnectToUSB(string port, int butrate)
        {
            if (!port.Equals(""))
            {
                myport = new SerialPort();
                myport.PortName = port;
                myport.BaudRate = butrate;
                myport.Open();
                timer1.Start();
                response = new Thread(reader);
                response.Start();
            }
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            if (myport.IsOpen)
            {
                comboBox1.Enabled = false;
                button2.Enabled = true;
                button1.Enabled = false;
            }
            if(mydata != null){
                var data = new JDecoder(mydata).getData();
                if (data != null)
                {
                    richTextBox1.Text =
                        "x_move: " + data.x + "\r\n" +
                        "y_move: " + data.y + "\r\n" +
                        "whell_move: " + data.wheel + " : Disabled\r\n" +
                        "left-click: " + data.left + "\r\n" +
                        "right-click: " + data.righ + "\r\n" +
                        "scroll-click: " + data.scroll + " : Disabled\r\n" +
                        "Read-Speed: " + delay + "ms\r\n";
                    controller.Mouse_move(data.x, data.y);
                    if (data.left)
                    {
                        controller.Leftclick(200);
                    }
                    if (data.righ)
                    {
                        controller.Rightclick(200);
                    }
                }
            }
        }
        private void reader()
        {
            if (myport != null && myport.IsOpen)
            {
                while ((mydata = myport.ReadLine()) != null)
                {
               ;
                }
            }
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (myport != null && myport.IsOpen)
            {
                timer1.Stop();
                timer2.Stop();
                if (response != null && response.IsAlive)
                {
                    response.Abort();
                    response = null;
                }
                myport.Close();
            }
        }

        private void timer2_Tick(object sender, EventArgs e)
        {
            if (myport == null || !myport.IsOpen)
            {
                Ports();
            }
        }

        private void trackBar1_Scroll(object sender, EventArgs e)
        {
            int timer = trackBar1.Value * 10;
            delay = timer;
        }
        private void resetPoint()
        {
            button2.Enabled = false;
            button1.Enabled = true;
            richTextBox1.Text = "";
            comboBox1.Enabled = true;
            timer2.Start();
        }
    }
    }
