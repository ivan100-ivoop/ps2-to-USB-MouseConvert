﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Newtonsoft.Json;

namespace Mouse
{
    class JDecoder
    {
        CustomDecoder jdata;
        public JDecoder(string data)
        {
            try
            {
                this.jdata = JsonConvert.DeserializeObject<CustomDecoder>(data);
            }
            catch{}
        }
        public CustomDecoder getData()
        {
            return this.jdata;
        }
    }
}
