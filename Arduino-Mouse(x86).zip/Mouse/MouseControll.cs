﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.InteropServices;
using System.Drawing;
using System.Threading;

namespace Mouse
{
    class MouseControll
    {
        public const uint MOUSEEVENTF_LEFTDOWN = 0x0002;
        public const uint MOUSEEVENTF_LEFTUP = 0x0004;
        public const uint MOUSEEVENTF_RIGHTDOWN = 0x0008;
        public const uint MOUSEEVENTF_RIGHTUP = 0x0010;
        public const uint MOUSEEVENTF_WHEEL = 0x0800;
        public const uint MOUSEEVENTF_HWHEEL = 0x01000;

        [DllImport("user32.dll")]
        static extern bool SetCursorPos(int X, int Y);
        [DllImport("user32.dll")]
        public static extern bool GetCursorPos(out Point p);
        [DllImport("user32.dll")]
        public static extern void mouse_event(uint dwFlags, uint dx, uint dy, uint dwData, int dwExtraInfo);

        private Form1 form1;

        public MouseControll(Form1 form1)
        {
            // TODO: Complete member initialization
            this.form1 = form1;
        }

        public void Mouse_move(int X, int Y)
        {
            if (X != 0 || Y != 0)
            {
                Point start = new Point();
                GetCursorPos(out start);
                int n_X = start.X + X;
                int n_Y = start.Y - Y;
                SetCursorPos(n_X, n_Y);
                Thread.Sleep(this.form1.delay);
            }
        }
        public void Leftclick(int time = 100)
        {
            mouse_event(MOUSEEVENTF_LEFTDOWN, 0, 0, 0, 0);
            Thread.Sleep(time);
            mouse_event(MOUSEEVENTF_LEFTUP, 0, 0, 0, 0);
        }
        public void Rightclick(int time = 100)
        {
            mouse_event(MOUSEEVENTF_RIGHTDOWN, 0, 0, 0, 0);
            Thread.Sleep(time);
            mouse_event(MOUSEEVENTF_RIGHTUP, 0, 0, 0, 0);
        }
        public void Wheelclick(int time = 100)
        {
            mouse_event(MOUSEEVENTF_LEFTDOWN, 0, 0, 0, 0);
            Thread.Sleep(time);
            mouse_event(MOUSEEVENTF_RIGHTUP, 0, 0, 0, 0);
        }
        public void Whell_Move(uint x)
        {
            mouse_event(MOUSEEVENTF_WHEEL, 0, 0, x, 0);
        }

    }
}
