﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Mouse
{
    class CustomDecoder
    {
        public int x { get; set; }
        public int y { get; set; }
        public int wheel { get; set; }
        public bool left { get; set; }
        public bool righ { get; set; }
        public bool scroll { get; set; }
    }
}
